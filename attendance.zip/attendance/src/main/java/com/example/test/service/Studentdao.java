package com.example.test.service;

import java.io.IOException;
import java.util.List;

import com.example.test.Model.Student;
import com.google.zxing.WriterException;

public interface Studentdao {
	public  List<Student> getAllStudents();
	public void  saveStudent(Student student) throws WriterException, IOException;

}
