  package com.example.test.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.test.Model.Attendance;
import com.example.test.Model.Student;
import com.example.test.repository.AttendanceRepo;
import com.example.test.repository.Studentrepo;

import java.util.List;

// Service class
@Service
public class AttendanceService {


	    @Autowired
	    private Studentrepo studentRepository;

	    @Autowired
	    private AttendanceRepo attendanceRepository;

	    
	    public void takeAttendance(String qrCodeContent) throws Exception {
	       
	        Student student = studentRepository.findByQrCodeImage(qrCodeContent);
	        if (student == null) {
	            throw new Exception("Student not found.");
	        }

	        Attendance attendance = new Attendance();
	        attendance.setStudent(student);
	        attendance.setTime(new Date());
	        attendanceRepository.save(attendance);
	    }
	

        


		public List<Attendance> getAllAttendance() {
		    List<Attendance> attendanceList = attendanceRepository.findAll();
		    return attendanceList;
		}

}

