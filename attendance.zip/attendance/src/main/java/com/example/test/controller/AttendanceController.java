package com.example.test.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.test.Model.Attendance;
import com.example.test.service.AttendanceService;




@RestController
public class AttendanceController {

    @Autowired
    private AttendanceService attendanceService;

    @PostMapping("/attendance")
    public ResponseEntity<String> takeAttendance(@RequestParam("qrCodeContent") String qrCodeContent) {
        try {
            attendanceService.takeAttendance(qrCodeContent);
            return ResponseEntity.ok("Attendance successfully taken.");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }
    }





   @GetMapping("/attendance1")
   public ResponseEntity<List<Attendance>> getAttendance() {
       List<Attendance> attendanceList = attendanceService.getAllAttendance();
       return ResponseEntity.ok(attendanceList);
   }
}






