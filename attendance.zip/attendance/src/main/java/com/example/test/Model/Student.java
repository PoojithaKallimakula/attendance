package com.example.test.Model;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
//import javax.persistence.JoinColumn;
import javax.persistence.Lob;
//import javax.persistence.OneToOne;
import javax.persistence.Table;
//import javax.transaction.Transactional;

import org.hibernate.annotations.ColumnDefault;
import org.hibernate.annotations.DynamicInsert;

//import lombok.Data;
//import lombok.NoArgsConstructor;



@Entity

@Table(name="student1")
@DynamicInsert
public class Student {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private  int sid;
	@ColumnDefault("19001A0")
	private String sadmin;
	@ColumnDefault("name")
	private String sname;
	@ColumnDefault("1")
	private String sbranch;
	@ColumnDefault("-1")
	private int syear;
	@ColumnDefault("xyz@gmail.com")
	private String sgmail;
	private String sph;
      @Lob
     private byte[] qrCodeImage;
	
	public byte[] getQrCodeImage() {
		return qrCodeImage;
	}
	public void setQrCodeImage(byte[] qrCodeImage) {
		this.qrCodeImage = qrCodeImage;
}
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	
	
	public String getSadmin() {
		return sadmin;
	}
	public void setSadmin(String sadmin) {
		this.sadmin = sadmin;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getSbranch() {
		return sbranch;
	}
	public void setSbranch(String sbranch) {
		this.sbranch = sbranch;
	}
	public int getSyear() {
		return syear;
	}
	public void setSyear(int syear) {
		this.syear = syear;
	}
	public String getSgmail() {
		return sgmail;
	}
	public void setSgmail(String sgmail) {
		this.sgmail = sgmail;
	}
	public String getSph() {
		return sph;
	}
	public void setSph(String sph) {
		this.sph = sph;
	}

	

}
