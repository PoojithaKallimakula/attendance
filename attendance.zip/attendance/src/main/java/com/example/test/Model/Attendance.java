package com.example.test.Model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity

public class Attendance {

	    @Id
	    @GeneratedValue(strategy = GenerationType.AUTO)
	    private Long id;
	     
	    @ManyToOne(fetch = FetchType.LAZY)
	    @JoinColumn(name = "sadmin", nullable = false)
	    private Student student;
	     
	    @Temporal(TemporalType.TIMESTAMP)
	    private Date time;


		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public Student getStudent() {
			return student;
		}

		public void setStudent(Student student) {
			this.student = student;
		}

		public Date getTime() {
			return time;
		}

		public void setTime(Date time) {
			this.time = time;
		}
	     
	    // constructors, getters and setters, and other fields
	}

    


